add_requires("mingw-w64")
