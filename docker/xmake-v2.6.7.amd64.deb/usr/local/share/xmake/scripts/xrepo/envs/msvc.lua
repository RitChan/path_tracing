if is_host("windows") then
    set_toolchains("msvc")
end
